  $ make
  gcc -Wall -Wextra -pedantic -c hola.c -o hola.o
  gcc -Wall -Wextra -pedantic hola.o -o hola